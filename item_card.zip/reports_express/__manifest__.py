{
            'name':'تقارير',
            'category':'Report',
            'depends':['base','sale'],
            'application':True,
            'author':'BBL',
            'data':['views/report_list_menu.xml','views/list_report_action.xml',]

}