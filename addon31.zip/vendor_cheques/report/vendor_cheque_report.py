from odoo import api, models
from dateutil.relativedelta import relativedelta
import datetime
import logging

_logger = logging.getLogger(__name__)


class ReportProductSale(models.AbstractModel):
    _name = "report.vendor_cheques.vendor_cheques_report"
​
    @api.model
    def _get_report_values(self, docids, data=None):
        date_from = data["form"]["date_from"]
        date_to = data["form"]["date_to"]
        vendor = data["form"]["vendor"]
        state = data["form"]["state"]
        due_date_from=data["form"]["due_date_from"]
        due_date_to=data["form"]["due_date_to"]
​
​
        total_sale = 0.0
        period_value = ""
        domain = []
        if date_from:
            domain.append(("check_payment", ">=", date_from))
        if date_to:
            domain.append(("check_payment", "<=", date_to))
        if vendor:
            domain.append(("investor_id", "=", vendor))
        if state:
            domain.append(("state", "=", state))
        if due_date_to:
            domain.append(("check_date", "<=", due_date_to))
        if due_date_from:
            domain.append(("check_date", ">=", due_date_from))
​
​
        list = []
        order_line = []
        cheques = self.env["check.management"].search(domain, order="check_date asc")
        state_value=''
        user_log=self.env['res.users'].search([('id','=',self.env.uid)])
        for line in cheques:
            if line.investor_id.supplier==True:
                
                if user_log.lang=='ar_SY' or user_log.lang=='ar_AA':
                    if line.state=='handed':
                        state_value='الصـــادره'
                    elif line.state=='debited':
                        state_value='المــدينــه'
                if line.state=='handed' or line.state=='debited':
                    list.append(
                        {
                            "cheque_number": line.check_number,
                            "cheque_date": line.check_date,
                            "check_payment": line.check_payment,
                            "partner": line.investor_id.name,
                            "state": state_value,
                            "check_bank": line.check_bank.name,
                            "dept_bank":line.dep_bank.name,
                            "deposite_bank":line.bank_deposite.name,
                            "total": line.amount,
                        }
            )
        state_value=''
        if state=='handed':
            state_value='الصـــادره'
        elif state=='debited':
            state_value='المــدينــه'
        
        
        
        if len(cheques) != 0:
            return {
                "doc_ids": data["ids"],
                "doc_model": data["model"],
                "period": period_value,
                "date_from": date_from,
                "date_to": date_to,
                "due_date_from": due_date_from,
                "due_date_to": due_date_to,
                "cheques": list,
                "total_sale": total_sale,
                "state": state_value,
                'vendor_name':self.env['res.partner'].search([('id','=',vendor)]).name,
                "data_check": False,
                "name_report":'بيــان بشيــكات مورد'
            }
        else:
            return {
                "doc_ids": data["ids"],
                "doc_model": data["model"],
                "period": period_value,
                "date_from": date_from,
                "date_to": date_to,
                "due_date_from": due_date_from,
                "due_date_to": due_date_to,
                "cheques": list,
                "total_sale": total_sale,
                "state": state_value,
                'vendor_name':self.env['res.partner'].search([('id','=',vendor)]).name,
                "data_check": True,
                "name_report":'بيــان بشيــكات مورد'
            }
​