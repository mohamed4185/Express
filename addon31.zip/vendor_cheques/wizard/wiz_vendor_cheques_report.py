
from odoo import api, fields, models


class PeriodicalReportProduct(models.TransientModel):
    _name = "vendor.cheques"

     
    date_from = fields.Date(string='تاريخ البدء')
    date_to = fields.Date(string='تاريخ الانتهاء')
    vendor=fields.Many2one('res.partner',string='المورد',domain="[('supplier','=',True)]")
    state = fields.Selection(selection=[('handed', 'صادرة'),('debited', 'مدينه')],string='الحالة')
    due_date_from=fields.Date(string=' تاريخ الاستـــحقاق من  ')
    due_date_to=fields.Date(string=' تاريخ الاستـــحقاق الـــي  ')
    @api.multi
    def check_report(self):
         
        data = {
            'ids': self.ids,
            'model': self._name,
            'form': {
                'date_from': self.date_from,
                'date_to': self.date_to,
                'vendor':self.vendor.id,
                'state':self.state,
                'due_date_from':self.due_date_from,
                'due_date_to':self.due_date_to


            },
        }
        return self.env.ref('vendor_cheques.action_report_vendor_cheques').report_action(self, data=data)
