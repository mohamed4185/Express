{
    'name': "sale Custimization Express",
    'summary': """Sale  Custimization Express""",
    'author': 'BBL',
    'website': '',
    'category': 'Sale Custimization',
    'version': '12.0.1.0.8',
    'depends': ['base','sale','purchase','account','sale_stock'],
    'data': ['views/sale_custom.xml','views/invoice_cus.xml'],
    'demo': [
    ],
    'qweb': [
        
    ],
    'auto-install':True,
	 
     
}